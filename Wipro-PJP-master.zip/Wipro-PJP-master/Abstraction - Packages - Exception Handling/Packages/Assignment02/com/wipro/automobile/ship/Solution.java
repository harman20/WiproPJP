package com.wipro.automobile.ship;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Compartment compartment = new Compartment(1005.15, 400.5, 588.2);
		
		System.out.println(compartment);
	}

}
