select last_name, job_id from employees 
where manager_id is null;